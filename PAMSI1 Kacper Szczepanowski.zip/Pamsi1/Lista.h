#pragma once
#include"sortowanie.h"
#include"inne_funkcje.h"

using namespace std;

/*!
 * \file  Lista.h
 *
 *  Plik zawiera definicję klas Wezel i ListaWiazana
 * 	i metody zdefiniowane dla tych klas
 */

/**
 * \brief Klasa wezel
 *  Jest podstawowym elementem listy wiazanej
 */

/// #################### wezel:  skladniki listy
template<class Typ>
class Wezel
{
public:
    int rozmiar;
    Typ *Tablica;

    Wezel<Typ> *Nast;

/*!
 * \brief  Konstruktor klasy Wezel
 *  Param konstruktor obiektu klasy Wezel, przyjmuje wartosc n-wielkosc Tablicy
 */
    Wezel(int n)
    {
        rozmiar=n;
        Tablica=new Typ[rozmiar];
        for(int i=0; i<n; i++)
            Tablica[i]=rand()%10000+1;

        Nast=NULL;
    }


/*!
 * \brief  Konstruktor klasy Wezel
 *  Bezparam konstruktor obiektu klasy Wezel, tworzy obiekt Wezel o tablicy 1000000 elem
 */
    Wezel()
    {
        rozmiar=1000000;
        Tablica= new Typ [rozmiar];

        Nast=NULL;
    }


/*!
 * \brief  szablon funkcji wypisującej wezel
 *  Wypisuje wartosci tablicy obiektu Wezel
 *  typ void
 */
    void WypiszWezel();

/*!
 * \brief  szablon funkcji sortujacej wezel metoda quick sort
 *  Wykorzystuje funckję SortowanieSzybkie(); do posortowania tablicy
  *  typ void
 */
    void SortujWezelSzybko();


/*!
 * \brief  szablon funkcji sortujacej wezel metoda quick sort
 *  Wykorzystuje funckję SortowaniePrzezScalanie(); do posortowania tablicy
 */
    void SortujWezelPrzezScalanie();


/*!
 * \brief  szablon funkcji sortujacej wezel metoda quick sort
 *  Wykorzystuje funckję SortowanieIntrospektwne(); do posortowania tablicy
 *  typ void
 */
    void SortujWezelIntrospektywnie();


/*!
 * \brief  szablon funkcji sortujacej wezel metoda quick sort
 *  Wykorzystuje funckję SortowanieSzybkieMalejaco(); do posortowania tablicy malejaco
 *  typ void
 */
    void SortujWezelSzybkoMalejaco();



/*!
 * \brief  szablon funkcji sortujaca wezel metoda quick sort
 *  Wykorzystuje funckję SortowanieSzybkieMalejaco(); do posortowania tablicy malejaco
 * przyjmu wartosc double z zakresu 0-100
 *  typ void
 */
    void SortujWezelSzybkoProcentowo(double procent);


/*!
 * \brief  szablon funkcji CzyPosortowanyWezel
 * uzywajac funkcji czyPosortowana(); sprawdza czy tablica wezla jest posortowana
 *  typ bool
 */
 bool CzyPosortowanyWezel();

 /*!
 * \brief  szablon funkcji CzyPosortowanyWezelMAlejaco
 * uzywajac funkcji czyPosortowanaMalejaco(); sprawdza czy tablica wezla jest posortowana
 *  typ bool
 */
 bool CzyPosortowanyWezelMalejaco();
};


/// ########### lista struktura x tablic
template<typename T>
void Wezel<T> :: SortujWezelSzybkoProcentowo(double procent)
{
    SortowanieSzybkie(Tablica, 0, ((rozmiar-1)*procent)/100);
}




template<typename T>
void Wezel<T> :: SortujWezelSzybko()
{
    SortowanieSzybkie(Tablica, 0, rozmiar-1);
}

template<typename T>
void Wezel<T> :: SortujWezelPrzezScalanie()
{
    SortowaniePrzezScalanie(Tablica, 0, rozmiar-1);
}

template<typename T>
void Wezel<T> :: SortujWezelIntrospektywnie()
{
    SortowanieIntrospektywne(Tablica, 0, rozmiar-1);
}

template<typename T>
void Wezel<T> :: SortujWezelSzybkoMalejaco()
{
    SortowanieMalejaco(Tablica, 0, rozmiar-1);
}


template <typename T>
void Wezel<T> :: WypiszWezel()
{
    for(int i =0; i<rozmiar; i++)
        cout<<Tablica[i]<<" ";
    cout<<endl;
}

template<typename T>
bool Wezel<T> :: CzyPosortowanyWezel()
{
   if(CzyPosortowana( Tablica, rozmiar)==true)
    return true;
   else
    return false;
}

template<typename T>
bool Wezel<T> :: CzyPosortowanyWezelMalejaco()
{
   if(CzyPosortowanaMalejaco( Tablica, rozmiar)==true)
    return true;
   else
    return false;

}

///################################ Lista jednokierunkowa

/**
 * \brief Klasa ListaWiazana
 *  Zbiór obiektow klasy Wezel
 */

template<class Typ>
class ListaWiazana
{
private:
    int licznik=0;

public:
    Wezel<Typ> * Glowa;

    Wezel<Typ> * Ogon;


/*!
 * \brief  szablon funkcji dodającej głowe Listy
 *  dodaje nowy element(obiekt Wezel) na poczatek listy
 */
    void DodajGlowe( int rozmiar);

/*!
 * \brief  Konstruktor klasy ListaWiazana
 *  Bezparam konstruktor obiektu klasy ListaWiazana, tworzy obiekt ListaWiazana
 */
    ListaWiazana();


/*!
 * \brief  Konstruktor klasy ListaWiazana
 *  Param konstruktor obiektu klasy ListaWiazana, tworzy obiekt ListaWiazana
 *  o podanej liczbie elementów i rozmiarze tablic
 *  przyjmuje dwie wartosci int
 */
    ListaWiazana(int ile, int rozmiar)
    {
        for(int i = 0; i<ile; i++)
        {
            DodajGlowe(rozmiar);
        }
    }

/*!
 * \brief  Wypisuje wszystkie tablice w liscie
 *  realizuje funkcje WypiszWezel(); dla kazdego elementu Listy
 * typ void
 */
    void WypiszListe();

    int DlugoscListy()
    {
        return licznik;
    }

/*!
 * \brief  szablon funkcji sortujacej Liste metoda quick sort
 *  Wykorzystuje funckję SortujWezelSzybko(); do posortowania
 * kadego elem listy
 */
    void SortujListeSzybko();

/*!
 * \brief  szablon funkcji sortujacej Liste metoda mergesort
 *  Wykorzystuje funckję SortujWezelPrzezScalanie(); do posortowania
 * kadego elem listy
 */
    void SortujListePrzezScalanie();

/*!
 * \brief  szablon funkcji sortujacej Liste metoda introsort
 *  Wykorzystuje funckję SortujWezelIntrospektywnie(); do posortowania
 * kadego elem listy
 */
    void SortujListeIntrospektywnie();

/*!
 * \brief  szablon funkcji sortujacej Liste metoda quick sort
 *  Wykorzystuje funckję SortujWezelSzybkoMalejaco(); do posortowania
 * kadego elem listy malejaco
 */
    void SortujListeSzybkoMalejaco();

    /*!
 * \brief  szablon funkcji sortujaca lsite metoda quick sort
 *  Wykorzystuje funckję SortujWezelSzybkoProcentowo(); do posortowania  procentowego kazdego elem listys
 *  typ void, pzryjmuje double zakres 0-100
 */
    void SortujListeSzybkoProcentowo(double procent);


/*!
 * \brief  szablon funkcji CzyListaPosortowana
 * sprawdza czy wezly w tablicy sa posortowane
 *  typ bool
 */
bool CzyListaPosortowana();

/*!
 * \brief  szablon funkcji CzyListaPosortowana
 * sprawdza czy wezly w tablicy sa posortowane malejaco
 *  typ bool
 */
bool CzyListaPosortowanaMalejaco();

};



template<typename T>
void ListaWiazana<T> :: DodajGlowe( int rozmiar)
{
    Wezel<T> * wezel  = new Wezel<T> (rozmiar);
    wezel->Nast=Glowa;

    Glowa=wezel;

    if(licznik==0)
    {
        Ogon=Glowa;
    }
    licznik++;
}


template<typename T>
void ListaWiazana<T> ::WypiszListe()
{
    Wezel<T> *wezel=Glowa;
    for(int i = 0; i<licznik; i++)
    {
        wezel->WypiszWezel();
        wezel=wezel->Nast;
    }
}


template<typename T>
void ListaWiazana<T> ::SortujListeSzybko()
{
    Wezel<T> *wezel=Glowa;
    for(int i = 0; i<licznik; i++)
    {
        //wezel->WypiszWezel();
        wezel->SortujWezelSzybko();

       // wezel->WypiszWezel();        cout<<endl;
        wezel=wezel->Nast;
    }
}

template<typename T>
void ListaWiazana<T> ::SortujListeSzybkoMalejaco()
{
    Wezel<T> *wezel=Glowa;
    for(int i = 0; i<licznik; i++)
    {
       // wezel->WypiszWezel();
        wezel->SortujWezelSzybkoMalejaco();

       // wezel->WypiszWezel();        cout<<endl;
        wezel=wezel->Nast;
    }
}


template<typename T>
void ListaWiazana<T> ::SortujListeIntrospektywnie()
{
    Wezel<T> *wezel=Glowa;
    for(int i = 0; i<licznik; i++)
    {
        //wezel->WypiszWezel();
        wezel->SortujWezelIntrospektywnie();

       // wezel->WypiszWezel();        cout<<endl;
        wezel=wezel->Nast;
    }
}

template<typename T>
void ListaWiazana<T> ::SortujListePrzezScalanie()
{
    Wezel<T> *wezel=Glowa;
    for(int i = 0; i<licznik; i++)
    {
        //wezel->WypiszWezel();
        wezel->SortujWezelPrzezScalanie();

       // wezel->WypiszWezel();        cout<<endl;
        wezel=wezel->Nast;
    }
}


template<typename T>
void ListaWiazana<T> ::SortujListeSzybkoProcentowo(double procent)
{
    Wezel<T> *wezel=Glowa;
    for(int i = 0; i<licznik; i++)
    {
        //wezel->WypiszWezel();
        wezel->SortujWezelSzybkoProcentowo(procent);

       // wezel->WypiszWezel();        cout<<endl;
        wezel=wezel->Nast;
    }
}



template<typename T>
bool ListaWiazana<T> ::CzyListaPosortowana()
{
    Wezel<T> *wezel=Glowa;
    for(int i = 0; i<licznik; i++)
    {
       if( wezel->CzyPosortowanyWezel()==true)
        return true;
       else
        return false;
        wezel=wezel->Nast;
    }
    return true;
}


template<typename T>
bool ListaWiazana<T> ::CzyListaPosortowanaMalejaco()
{
    Wezel<T> *wezel=Glowa;
    for(int i = 0; i<licznik; i++)
    {
       if( wezel->CzyPosortowanyWezelMalejaco()==true)
        return true;
       else
        return false;
        wezel=wezel->Nast;
    }
    return true;
}
