#include <iostream>
#include "sortowanie.h"
#include<ctime>
#include"Lista.h"
#include<chrono>
#include "testy.h"
using namespace std;




int main()
{


//plik<<4<<endl<<152;
/// ###### TESTY DZIALANIA ALGORYTMOW I FUNKCJI
/*
test_sortowan();
test_wezla();
test_listy();
*/

testy_glowne();
//plik.close();
return 0;
}
