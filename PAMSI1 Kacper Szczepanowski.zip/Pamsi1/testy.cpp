#include "testy.h"
using namespace std;

int ile;
double czas;

double Procent[7]= {0.0, 25.0, 50.0, 75.0, 95.0, 99.0, 99.7};
int WielkoscTab[5]= {10000, 50000, 100000, 500000, 1000000};
#define ZESTAW 100

int test_sortowan()
{
    cout << "Porownanie czasow sortowania v.1" << endl;
    cout<<"Ile losowych liczb w tablicy: ";
    cin>>ile;

    int *tablica;
    tablica=new int [ile];

    int *tablica2;
    tablica2=new int [ile];

    int *tablica3;
    tablica3=new int [ile];

    int *tablica4;
    tablica4=new int [ile];


    srand(time(NULL));

    for(int i=0; i<ile; i++)
    {
        tablica[i] = rand()%1000+1;
        tablica2[i]=tablica[i];
        tablica3[i]=tablica[i];
        tablica4[i]=tablica[i];
    }
    cout<<"Takie są tablice do sortowania: \n";
    WypiszTabele<int>(tablica, ile);
    WypiszTabele<int>(tablica2, ile);
    WypiszTabele<int>(tablica3, ile);
    WypiszTabele<int>(tablica4, ile);
    cout<<endl<<endl;
//////////////////////////////////////////quick sort
    cout<<"Przed posortowaniem quick: "<<endl;
    WypiszTabele<int>(tablica, ile);
    cout<<endl<<"Sortuje teraz szybko. Prosze czekac!"<<endl;
    SortowanieSzybkie <int> (tablica, 0, ile-1);
    WypiszTabele<int>(tablica, ile);
    if(CzyPosortowana(tablica, ile)==true )
        cout<<"Posortowana! :D ";
    else
        return 1;
    cout<<endl<<endl;
////////////////////////////////////// mergesort
    cout<<"Przed posortowaniem merge: "<<endl;
    WypiszTabele<int>(tablica2, ile);
    cout<<endl<<"Sortuje teraz scalajac. Prosze czekac!"<<endl;
    SortowaniePrzezScalanie <int> (tablica2, 0, ile-1);
    cout<<endl<<"Po posortowaniu merge: "<<endl;
    WypiszTabele<int>(tablica2, ile);
    if(CzyPosortowana(tablica2, ile)==true )
        cout<<"Posortowana! :D ";
    else
        return 1;
    cout<<endl<<endl;

/////////////////// introsort
    cout<<"Przed posortowaniem hybrydowym: "<<endl;
    WypiszTabele<int>(tablica3, ile);
    cout<<endl<<"Sortuje teraz hybrydowo. Prosze czekac!"<<endl;
    SortowanieIntrospektywne(tablica3, 0, ile-1);
    cout<<endl<<"Po posortowaniu hybrydowym: "<<endl;
    WypiszTabele<int>(tablica3, ile);
    if(CzyPosortowana(tablica3, ile)==true )
        cout<<"Posortowana! :D ";
    else
        return 1;
    cout<<endl<<endl;


/////////////////////// quick sort malejaco

    cout<<endl<<"Sortuje teraz szybko malejaco. Prosze czekac!"<<endl;
    SortowanieMalejaco <int> (tablica4, 0, ile-1);
    cout<<endl<<"Po posortowaniem quick malejaco: "<<endl;
    WypiszTabele<int>(tablica4, ile);
    if(CzyPosortowanaMalejaco(tablica4, ile)==true )
        cout<<"Posortowana Malejaco! :D ";
    else
        return 1;

    cout<<endl<<endl;

    delete [] tablica;
    delete [] tablica2;
    delete [] tablica3;
    delete [] tablica4;
    return 0;
}
///############## testy v2

int test_wezla()

{


    cout << "Porownanie czasow sortowania v.2" << endl;
    cout<<"Ile losowych liczb w tablicy: ";
    cin>>ile;
    ///###### test na wezlach
    Wezel<int> * wezel= new Wezel<int>(ile);
    Wezel<int> * wezel1= new Wezel<int>(ile);
    Wezel<int> * wezel2= new Wezel<int>(ile);
    Wezel<int> * wezel3= new Wezel<int>(ile);
    Wezel<int> * wezel4= new Wezel<int>(ile);


//////////////////////////////////////////quick sort
    cout<<"Przed posortowaniem quick: "<<endl;
    wezel->WypiszWezel();
    cout<<endl<<"Sortuje teraz szybko. Prosze czekac!"<<endl;
    wezel->SortujWezelSzybko();
    wezel->WypiszWezel();
    if(wezel->CzyPosortowanyWezel()==true )
        cout<<"Posortowany! :D ";
    else
        return 1;
    cout<<endl<<endl;
////////////////////////////////////// mergesort
    cout<<"Przed posortowaniem merge: "<<endl;
    wezel1->WypiszWezel();
    cout<<endl<<"Sortuje teraz merge. Prosze czekac!"<<endl;
    wezel1->SortujWezelPrzezScalanie();
    wezel1->WypiszWezel();
    if(wezel1->CzyPosortowanyWezel()==true )
        cout<<"Posortowany! :D ";
    else
        return 1;
    cout<<endl<<endl;
    ////////////////////// introsort
    cout<<"Przed posortowaniem merge: "<<endl;
    wezel2->WypiszWezel();
    cout<<endl<<"Sortuje teraz merge. Prosze czekac!"<<endl;
    wezel2->SortujWezelIntrospektywnie();
    wezel2->WypiszWezel();
    if(wezel2->CzyPosortowanyWezel()==true )
        cout<<"Posortowany! :D ";
    else
        return 1;
    cout<<endl<<endl;
    ////// odwrotnie
    cout<<"Przed posortowaniem quick odw: "<<endl;
    wezel3->WypiszWezel();
    cout<<endl<<"Sortuje teraz szybko odw. Prosze czekac!"<<endl;
    wezel3->SortujWezelSzybkoMalejaco();
    wezel3->WypiszWezel();
    if(wezel3->CzyPosortowanyWezel()==true )
        cout<<"Posortowany! :D ";
    else
        return 1;
    cout<<endl<<endl;
    ////// procentowo
    cout<<"Przed posortowaniem quick proc: "<<endl;
    wezel4->WypiszWezel();
    cout<<endl<<"Sortuje teraz szybko proc. Prosze czekac!"<<endl;
    wezel4->SortujWezelSzybkoProcentowo(50);
    wezel4->WypiszWezel();
    cout<<endl<<endl;

    return 0;

}

int test_listy()
{

    cout << "Porownanie czasow sortowania v.2" << endl;
    ListaWiazana<int> * Lista;
    Lista=new ListaWiazana<int>(10, 10);
    cout<<endl<<endl;
    cout<<"po sortowaniu quick\n";
    Lista->SortujListeSzybko();
    Lista->WypiszListe();
    if(Lista->CzyListaPosortowana()==true)
        cout<<"Posortowane"<<endl;
    delete Lista;


    ListaWiazana<int> * Lista1;
    Lista1=new ListaWiazana<int>(10, 10);
    cout<<endl<<endl;
    cout<<"po sortowaniu intro\n";
    Lista1->SortujListeIntrospektywnie();
    Lista1->WypiszListe();
    if(Lista1->CzyListaPosortowana()==true)
        cout<<"Posortowane"<<endl;
    delete Lista1;



    ListaWiazana<int> * Lista2;
    Lista2=new ListaWiazana<int>(10, 10);
    cout<<endl<<endl;
    cout<<"po sortowaniu merge\n";
    Lista2->SortujListePrzezScalanie();
    Lista2->WypiszListe();
    if(Lista2->CzyListaPosortowana()==true)
        cout<<"Posortowane"<<endl;
    delete Lista2;

    ListaWiazana<int> * Lista3;
    Lista3=new ListaWiazana<int>(10, 10);
    cout<<endl<<endl;
    cout<<"po sortowaniu merge\n";
    Lista3->SortujListeSzybkoMalejaco();
    Lista3->WypiszListe();
    if(Lista3->CzyListaPosortowanaMalejaco()==true)
        cout<<"Posortowane"<<endl;
    delete Lista3;


    ListaWiazana<int> * Lista4;
    Lista4=new ListaWiazana<int>(10, 10);
    cout<<endl<<endl;
    cout<<"po sortowaniu merge\n";
    Lista4->SortujListeSzybkoProcentowo(50);
    Lista4->WypiszListe();
    delete Lista4;

    return 0;
}


int testy_glowne()
{

    ofstream plik;
    plik.open("testy.txt");

    srand(time(NULL));



    for(int i=0; i<5; i++)
    {
        plik<<"wielkosc tablic: "<<WielkoscTab[i]<<endl;
        //int wielkosc=WielkoscTab[i];
        for(int j=0; j<7; j++)
        {
            plik<<"procent posortowania: "<<Procent[j]<<endl;
            ListaWiazana<int> * Lista;
            Lista=new ListaWiazana<int>(ZESTAW,WielkoscTab[i]);
            Lista->SortujListeSzybkoProcentowo(Procent[j]);
            cout<<endl<<endl;
            cout<<"po sortowaniu quick\n";
            plik<<endl<<endl;
            plik<<"po sortowaniu quick\n";
            auto t_start = std::chrono::high_resolution_clock::now(); //start zegara
            Lista->SortujListeSzybko();
            auto t_end = std::chrono::high_resolution_clock::now(); //stop zegara
            cout<<(std::chrono::duration<double, std::milli>(t_end - t_start).count());
            plik<<(std::chrono::duration<double, std::milli>(t_end - t_start).count());
            plik<<endl;
            delete Lista;


            ListaWiazana<int> * Lista1;
            Lista1=new ListaWiazana<int>(ZESTAW, WielkoscTab[i]);
            Lista1->SortujListeSzybkoProcentowo(Procent[j]);
            cout<<endl<<endl;
            cout<<"po sortowaniu intro\n";
            plik<<endl<<endl;
            plik<<"po sortowaniu intro\n";
            auto t_start1 = std::chrono::high_resolution_clock::now(); //start zegara
            Lista1->SortujListeIntrospektywnie();
            auto t_end1 = std::chrono::high_resolution_clock::now(); //stop zegara
            cout<<(std::chrono::duration<double, std::milli>(t_end1 - t_start1).count());
            plik<<(std::chrono::duration<double, std::milli>(t_end1 - t_start1).count());
            plik<<endl;
            delete Lista1;



            ListaWiazana<int> * Lista2;
            Lista2=new ListaWiazana<int>(ZESTAW, WielkoscTab[i]);
            Lista2->SortujListeSzybkoProcentowo(Procent[j]);
            cout<<endl<<endl;
            cout<<"po sortowaniu merge\n";
            plik<<endl<<endl;
            plik<<"po sortowaniu merge\n";
            auto t_start2 = std::chrono::high_resolution_clock::now(); //start zegara
            Lista2->SortujListePrzezScalanie();
            auto t_end2 = std::chrono::high_resolution_clock::now(); //stop zegara
            cout<<(std::chrono::duration<double, std::milli>(t_end2 - t_start2).count());
            plik<<(std::chrono::duration<double, std::milli>(t_end2 - t_start2).count());
            plik<<endl;
            delete Lista2;


        }
    }
    plik<<"posortowane odwrotnie"<<endl;
    for(int i=0; i<5; i++)
    {
        plik<<"wielkosc tablic: "<<WielkoscTab[i]<<endl;
        ListaWiazana<int> * Lista;
        Lista=new ListaWiazana<int>(ZESTAW,WielkoscTab[i]);
        Lista->SortujListeSzybkoMalejaco();
        cout<<endl<<endl;
        cout<<"po sortowaniu quick\n";
        plik<<endl<<endl;
        plik<<"po sortowaniu quick\n";
        auto t_start = std::chrono::high_resolution_clock::now(); //start zegara
        Lista->SortujListeSzybko();
        auto t_end = std::chrono::high_resolution_clock::now(); //stop zegara
        cout<<(std::chrono::duration<double, std::milli>(t_end - t_start).count());
        plik<<(std::chrono::duration<double, std::milli>(t_end - t_start).count());
        plik<<endl;
        delete Lista;


        ListaWiazana<int> * Lista1;
        Lista1=new ListaWiazana<int>(ZESTAW, WielkoscTab[i]);
        Lista1->SortujListeSzybkoMalejaco();
        cout<<endl<<endl;
        cout<<"po sortowaniu intro\n";
        plik<<endl<<endl;
        plik<<"po sortowaniu intro\n";
        auto t_start1 = std::chrono::high_resolution_clock::now(); //start zegara
        Lista1->SortujListeIntrospektywnie();
        auto t_end1 = std::chrono::high_resolution_clock::now(); //stop zegara
        cout<<(std::chrono::duration<double, std::milli>(t_end1 - t_start1).count());
        plik<<(std::chrono::duration<double, std::milli>(t_end1 - t_start1).count());
        plik<<endl;
        delete Lista1;



        ListaWiazana<int> * Lista2;
        Lista2=new ListaWiazana<int>(ZESTAW, WielkoscTab[i]);
        Lista2->SortujListeSzybkoMalejaco();
        cout<<endl<<endl;
        cout<<"po sortowaniu merge\n";
        plik<<endl<<endl;
        plik<<"po sortowaniu merge\n";
        auto t_start2 = std::chrono::high_resolution_clock::now(); //start zegara
        Lista2->SortujListePrzezScalanie();
        auto t_end2 = std::chrono::high_resolution_clock::now(); //stop zegara
        cout<<(std::chrono::duration<double, std::milli>(t_end2 - t_start2).count());
        plik<<(std::chrono::duration<double, std::milli>(t_end2 - t_start2).count());
        plik<<endl;
        delete Lista2;
    }




    plik.close();
    return 0 ;
}
