#pragma once
#include <iostream>
#include<math.h>
#include<time.h>
#include <chrono>
#include<unistd.h>
#include<algorithm>
#include "inne_funkcje.h"
using namespace std;

/*!
 * \file  sortowanie.h
 *
 * Definicje funckji realizujących algorytmy sortowania
 * Sortowanie: Szybkie, Przez Kopcowanie i Introspektywne
 */




/// I szybkie


/*!
 * \brief  szablon SortowanieSzybkie
 * realizuje Sortowanie metoda quicksort
 * typ void,  przyjmuje wskaznik na tablice, indeksy elementu pierwszego
 * i ostatniego
 */
template<typename Typ>
void SortowanieSzybkie(Typ *tablica, int poczatek, int koniec)
{
int v=tablica[(poczatek+koniec)/2];
//int v =*SrodkowaTrzechLiczb(tablica, &tablica[(poczatek+koniec)/2], &tablica[koniec]);

    int i,j;
    i=poczatek;
    j=koniec;
    do
    {
        while(tablica[i]<v) i++;
        while(tablica[j]>v) j--;
        if(i<=j)
        {
          swap(tablica[i], tablica[j]);
            i++;
            j--;
        }
    }
    while(i<=j);
    if(j>poczatek) SortowanieSzybkie <Typ> (tablica,poczatek, j);
    if(i<koniec) SortowanieSzybkie <Typ> (tablica, i, koniec);
}



/// II Przez scalanie

/*!
 * \brief  szablon funckji Scalanie
 * scala posortowane elementy pierwotnej tablicy, w posortowany ciąg
 * typ void,  przyjmuje wskaznik na tablice, indeksy elementu pierwszego,
 * srodkowego i ostatniego
 */
template<typename Typ>
void Scalanie(Typ *tab, int poczatek, int srodek, int koniec)
{
    int *pom;
    pom=new int[koniec+1];
  int i, j;

  for(i = srodek + 1; i>poczatek; i--)
    pom[i-1] = tab[i-1];

  for(j = srodek; j<koniec; j++)
    pom[koniec+srodek-j] = tab[j+1];

  for(int k=poczatek; k<=koniec;k++)
  {
    if(pom[j]<pom[i])
      tab[k] = pom[j--];
    else
      tab[k] = pom[i++];
      }
     delete pom;
}


/*!
 * \brief  szablon funkcji SortowaniePrzezScalanie
 * realizuje Sortowanie metoda mergesort
 * typ void,  przyjmuje wskaznik na tablice, indeksy elementu pierwszego
 * i ostatniego
 */
template<typename Typ>
void SortowaniePrzezScalanie(Typ *tab,int poczatek, int koniec)
{
    int srodek;
	if(koniec>poczatek)
    {
	srodek = (koniec+poczatek)/2;
        //dzielenie na dwa rowne podzbiory i wywolanie funkcji dla kazdego z osobna
	SortowaniePrzezScalanie<Typ>(tab, poczatek, srodek);
	SortowaniePrzezScalanie<Typ>(tab, srodek+1, koniec);
    //scalenie
	Scalanie<Typ>(tab, poczatek, srodek, koniec);
    }
}


/// III introsort(hybryda)
//partycjonowanie

/*!
 * \brief  szablon funkcji Partycjonowanie
 * Wybiera os podzialu zgodnie z metoda quick sort
 * typ int, zwraca int
 */
template<typename Typ>
int Partycjonowanie(Typ *tab, int Lewy, int Prawy)
{
    int Os = tab[(Lewy + Prawy) / 2];
    int i = Lewy, j = Prawy;

    while (true)
    {
        while (tab[j] > Os) j--;

        while (tab[i] < Os) i++;

        if (i < j)  swap(tab[i++], tab[j--]);
        else return j;
    }
}

//wstawianie
/*!
 * \brief  szablon funckji Wstawianie
 * realizuje Sortowanie metoda insertionSort
 * typ void,  przyjmuje wskaznik na tablice, indeksy elementu skrajnych lewego
 * i prawego, dla podanej tablicy/fragmenty tablicy
 */
template<typename Typ>
void Wstawianie(Typ *tab, int Lewy, int Prawy)
{
	for (int i = Lewy + 1; i <= Prawy; i++)
	{
		int Klucz = tab[i];
		int j = i;

		while (j > Lewy && tab[j - 1] > Klucz)
        {
            tab[j] = tab[j - 1];
            j--;
        }
		tab[j] = Klucz;
	}
}


//Przez Kopcowanie
/*!
 * \brief  szablon funkcji SortowaniePrzezKopcowanie
 * realizuje Sortowanie metoda heapsort z biblioteki algorithms(make_heap i sort_heap)
 * typ void,  przyjmuje wskazniki na indeksy  skrajnych elementow lewego
 * i prawego, dla podanej tablicy/fragmentu tablicy
 */
template<typename Typ>
void SortowaniePrzezKopcowanie(Typ *Lewy, Typ *Prawy)
{
	make_heap(Lewy, Prawy);
	sort_heap(Lewy, Prawy);
}


//hybryda

/*!
 * \brief  szablon funckji SortowanieHybrydowe
 * realizuje wlasciwe Sortowanie metoda IntroSort
 * typ void,  przyjmuje wskaznik na tablice,wskazniki na  elementy skrajne lewego
 * i prawego, dla podanej tablicy/fragmenty tablicy oraz maksymalną glebokosc rekursji
 */
template<typename Typ>
void SortowanieHybrydowe(Typ *tab, Typ *lewy, Typ *prawy, int maxGlebokosc)
{
	if ((prawy - lewy) < 16)
        Wstawianie(tab, lewy - tab, prawy - tab);
	else if (maxGlebokosc == 0)
        SortowaniePrzezKopcowanie(lewy, prawy + 1);
	else
    {
		int Os = Partycjonowanie(tab, lewy - tab, prawy - tab);
		SortowanieHybrydowe(tab, lewy, tab + Os, maxGlebokosc - 1);
		SortowanieHybrydowe(tab, tab + Os + 1, prawy, maxGlebokosc - 1);
    }
}

/*!
 * \brief  szablon funckji SortowanieIntrospektywne
 * oblicza maksymalna glebokosc rekursji i wywoluje wlasciwe sortowanie introspektywne
 * typ void,  przyjmuje wskaznik na tablice, indeksy elementow skrajnych lewego
 * i prawego, dla podanej tablicy/fragmentu tablicy
 */
template<typename Typ>
void SortowanieIntrospektywne(Typ *tab,  int lewy, int prawy)
{
    int maxGlebokosc=2*log(prawy-lewy); //max gleb 2*log2(dl tablicy)
    SortowanieHybrydowe(tab, tab, tab + prawy , maxGlebokosc);
}


/// IV Sortowanie malejąco
/*!
 * \brief  szablon SortowanieSzybkieMalejaco
 * wlasciwosci takie jak funckja SortowanieSzybkie();
 * jednakze realizuje sortowanie malejaco
 */
template <typename Typ>
void SortowanieMalejaco(Typ *tablica, int poczatek, int koniec)
{
int v=tablica[(poczatek+koniec)/2];
    int i,j;
    i=poczatek;
    j=koniec;
    do
    {//zmiana kolejnosci porownania w petlach while, zmienia kolejnosc sortowania rosnaco->malejaco
        while(tablica[i]>v) i++;
        while(tablica[j]<v) j--;
        if(i<=j)
        {
          swap(tablica[i], tablica[j]);
            i++;
            j--;
        }
    }
    while(i<=j);
    if(j>poczatek) SortowanieMalejaco <Typ> (tablica,poczatek, j);
    if(i<koniec) SortowanieMalejaco <Typ> (tablica, i, koniec);
}
