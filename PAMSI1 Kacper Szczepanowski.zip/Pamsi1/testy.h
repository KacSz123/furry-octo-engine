#pragma once
#include<fstream>
#include"sortowanie.h"
#include "Lista.h"





/*!
 * \brief  funkcja Test
 * realizuje podstawowe funkjce i sprawdza
 * ich realizacje na tabicahc i/lub mozliwe bledy
 */
int test_sortowan();

/*!
 * \brief  funkcja Test
 * realizuje podstawowe funkjce i sprawdza
 * ich realizacje na wezlechi/lub mozliwe bledy
 */
int test_wezla();

/*!
 * \brief  funkcja Test
 * realizuje podstawowe funkjce i sprawdza
 * ich realizacje na listach/lub mozliwe bledy
 */
int test_listy();

/*!
 * \brief  funkcja Testy_glowne
 * realizuje sortowanie 100 tablic o konkretnych
 * rozmiarach i stopniach sortowania, sprawdza
 * ich realizacje i/lub mozliwe bledy
 * oblciza czas sortowan
 */
int testy_glowne();

