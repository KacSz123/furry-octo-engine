
#pragma once
#include <iostream>
#include<math.h>
#include<time.h>
#include <chrono>
#include<unistd.h>
#include"sortowanie.h"

using namespace std;

/*!
 * \file  inne_funkcje.h
 *
 *  funkjce podstawowe, dzialajace na tablicach
 */




/*!
 * \brief  szablon funkcji zamien
 *  zamienia wartosci dwoch obiektow
 * przyjmuje dwa adresy
 * z powodu niewydajnosci zastapiana funkcja swap() z biblioteki <algorithms>
 *//*
template<typename Typ>
void  zamien(Typ &k, Typ &l)
{
    int temp= k;
    k=l;
    l=temp;

}*/


/*!
 * \brief  szablon funkcji wypiszTabele
 * wykorzystuje petle do wypisania kolejnych elem tablicy
 * typ void, przyjmuje wskaznik na tablice i jej rozmiar
 */
template <typename Typ>
void WypiszTabele(Typ *tab, int n)
{
    for (int i=0; i<n; ++i)
        cout << tab[i] << " ";
    cout << "\n";
}



/*!
 * \brief  szablon funkcji Czy posortowana
 * wykorzystuje petle aby porownac kolejne elementy tablicy
 * i sprawdzic czy jest posortowana
 * typ bool, przyjmuje wskaznik na tablice i jej rozmiar
 */
template<typename Typ>
bool CzyPosortowana(Typ *tab, int koniec)
{
	for(int i=0; i<koniec; i++)
	{
		if(tab[i] > tab[i+1])
		{
			return false;
		} else
		{
			return true;
		}
	}
	return true;
}


/*!
 * \brief  szablon funkcji Czy posortowana
 * wykorzystuje petle aby porownac kolejne elementy tablicy
 * i sprawdzic czy jest posortowana malejaco
 * typ bool, przyjmuje wskaznik na tablice i jej rozmiar
 */
template<typename Typ>
bool CzyPosortowanaMalejaco(Typ *tab, int koniec)
{
	for(int i=0; i<koniec; i++)
	{
		if(tab[i] < tab[i+1])
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	return true;
}


/*!
 * \brief  szablon funkcji SrodkowaTrzechLiczb
 * porownuje trzy wartosci i zwraca srodkowa z nich
 * typ *int, przyjmuje trzy wartosci wskaznikowe
 *///spowalnala sortowania

template<typename Typ>
Typ *SrodkowaTrzechLiczb(Typ * a, Typ * b, Typ * c)
{
    if ((*a < *b && *b < *c) || (*c <= *b && *b <= *a) )
        return (b);

    else if ((*a < *c && *c <= *b) || (*b < *c && *c <= *a))
        return (c);

   else
   return(a);

}




